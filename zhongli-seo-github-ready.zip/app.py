from __future__ import annotations

import os
from pathlib import Path

from flask import Flask, redirect, render_template, request, url_for

from scheduler import Employee, Event, LeaveRecord, build_summary, schedule
from store import (
    DEFAULT_BRANDS,
    DEFAULT_GROUPS,
    DEFAULT_STORES,
    execute,
    init_db,
    query_all,
    seed_defaults,
)


BASE_DIR = Path(__file__).resolve().parent
WEEKDAY_OPTIONS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
SLOT_OPTIONS = ["AM", "PM"]
LEAVE_SLOT_OPTIONS = ["AM", "PM", "FULL"]


app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024


SITE_URL = "https://zhongli-seo.example.com"
SITE_NAME = "中壢在地 SEO 工作室"
SITE_PHONE = "03-425-9008"
SITE_ADDRESS = "桃園市中壢區中正路 168 號 8 樓"


def bootstrap() -> None:
    init_db()
    seed_defaults()


def to_csv(values: list[str]) -> str:
    return ",".join(value for value in values if value)


def fetch_employees() -> list[dict]:
    return query_all(
        """
        SELECT
            id,
            name,
            groups_text,
            available_days,
            available_slots,
            weekly_max_shifts,
            priority,
            notes
        FROM employees
        ORDER BY name COLLATE NOCASE
        """
    )


def fetch_leaves() -> list[dict]:
    return query_all(
        """
        SELECT
            leaves.id,
            leaves.date,
            leaves.slot,
            leaves.reason,
            employees.name AS employee_name
        FROM leaves
        JOIN employees ON employees.id = leaves.employee_id
        ORDER BY leaves.date, leaves.slot, employees.name
        """
    )


def fetch_events() -> list[dict]:
    return query_all(
        """
        SELECT
            id,
            date,
            slot,
            store,
            brand,
            category,
            required_staff,
            preferred_group,
            notes
        FROM events
        ORDER BY date, slot, store, brand
        """
    )


def build_scheduler_inputs() -> tuple[dict[str, Employee], list[LeaveRecord], list[Event]]:
    employees = {}
    for row in fetch_employees():
        employee_id = f"E{row['id']:03d}"
        employees[employee_id] = Employee(
            employee_id=employee_id,
            name=row["name"],
            groups={part.strip().lower() for part in row["groups_text"].split(",") if part.strip()},
            available_days={part.strip() for part in row["available_days"].split(",") if part.strip()},
            available_slots={part.strip().upper() for part in row["available_slots"].split(",") if part.strip()},
            weekly_max_shifts=row["weekly_max_shifts"],
            priority=row["priority"],
            notes=row["notes"],
        )

    name_to_code = {row["name"]: f"E{row['id']:03d}" for row in fetch_employees()}
    leaves = []
    for row in fetch_leaves():
        employee_code = name_to_code.get(row["employee_name"])
        if employee_code:
            leaves.append(
                LeaveRecord(
                    employee_id=employee_code,
                    date=row["date"],
                    slot=row["slot"],
                    reason=row["reason"],
                )
            )

    events = []
    for row in fetch_events():
        events.append(
            Event(
                event_id=f"EV{row['id']:03d}",
                date=row["date"],
                slot=row["slot"],
                store=row["store"],
                brand=row["brand"],
                category=row["category"].lower(),
                required_staff=row["required_staff"],
                preferred_group=(row["preferred_group"] or row["category"]).lower(),
                notes=row["notes"],
            )
        )

    return employees, leaves, events


def dashboard_context(message: str | None = None, active_tab: str = "employees") -> dict:
    employees = fetch_employees()
    leaves = fetch_leaves()
    events = fetch_events()
    return {
        "message": message,
        "active_tab": active_tab,
        "employees": employees,
        "leaves": leaves,
        "events": events,
        "group_options": DEFAULT_GROUPS,
        "store_options": DEFAULT_STORES,
        "brand_options": DEFAULT_BRANDS,
        "weekday_options": WEEKDAY_OPTIONS,
        "slot_options": SLOT_OPTIONS,
        "leave_slot_options": LEAVE_SLOT_OPTIONS,
        "stats": {
            "employees": len(employees),
            "events": len(events),
            "leaves": len(leaves),
        },
    }


def seo_context() -> dict:
    site_url = os.environ.get("SITE_URL", "").rstrip("/") or request.url_root.rstrip("/")
    faq_items = [
        {
            "question": "中壢在地 SEO 和一般 SEO 公司有什麼差別？",
            "answer": "在地 SEO 會把商圈、行政區、通勤動線、Google 商家檔案與區域型關鍵字一起規劃，更適合中壢實體店面、診所、室內設計、法律與教育品牌。",
        },
        {
            "question": "多久會看到中壢 SEO 成效？",
            "answer": "通常 6 到 12 週可以看見關鍵字與自然流量開始成長，但實際速度會受網站基礎、競爭度與內容量影響。",
        },
        {
            "question": "你們會幫忙 Google 商家優化嗎？",
            "answer": "會，我們會同步處理 Google 商家檔案、評論策略、NAP 一致性與在地頁面內容，讓地圖與自然搜尋一起成長。",
        },
        {
            "question": "如果我主要客戶在中壢、內壢、青埔，也適合做這種網站嗎？",
            "answer": "適合，我們可以依照服務區域建立對應頁面與內容主題，把中壢、內壢、青埔等區域需求分開布局。",
        },
    ]

    local_business_schema = {
        "@context": "https://schema.org",
        "@type": "ProfessionalService",
        "name": SITE_NAME,
        "image": f"{site_url}/static/og-zhongli-seo.jpg",
        "url": site_url,
        "telephone": SITE_PHONE,
        "address": {
            "@type": "PostalAddress",
            "streetAddress": SITE_ADDRESS,
            "addressLocality": "中壢區",
            "addressRegion": "桃園市",
            "addressCountry": "TW",
        },
        "areaServed": ["中壢區", "內壢", "青埔", "平鎮區", "楊梅區"],
        "priceRange": "$$",
        "description": "專做中壢在地商家 SEO、Google 商家優化、內容佈局與轉換頁設計。",
    }

    faq_schema = {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
            {
                "@type": "Question",
                "name": item["question"],
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": item["answer"],
                },
            }
            for item in faq_items
        ],
    }

    return {
        "site_name": SITE_NAME,
        "site_url": site_url,
        "site_phone": SITE_PHONE,
        "site_address": SITE_ADDRESS,
        "meta_title": "中壢 SEO 公司推薦｜中壢在地經營、Google 商家優化、網站自然排名",
        "meta_description": "提供中壢在地 SEO、Google 商家優化、內容規劃與轉換頁設計，幫助中壢店家在「中壢推薦」「中壢附近」「桃園中壢」相關搜尋中穩定曝光。",
        "hero_tags": ["中壢 SEO", "Google 商家優化", "在地關鍵字佈局", "桃園網站排名"],
        "service_cards": [
            {
                "eyebrow": "Local SEO",
                "title": "中壢商圈關鍵字布局",
                "body": "從中壢火車站、SOGO、內壢、青埔到工業區周邊，我們會依實際商圈意圖規劃頁面與內容。",
            },
            {
                "eyebrow": "Google Business Profile",
                "title": "地圖與商家檔案同步優化",
                "body": "把 Google 商家、評論策略、問答與網站內容串起來，提升地圖能見度與來電率。",
            },
            {
                "eyebrow": "Content Strategy",
                "title": "在地內容與常見問題頁",
                "body": "建立能吃到長尾搜尋的 FAQ、案例頁與服務頁，讓網站不只漂亮，也能持續累積排名。",
            },
        ],
        "process_steps": [
            "盤點目前網站、Google 商家與競品在中壢的能見度。",
            "定義核心關鍵字、服務區域頁與轉換頁架構。",
            "優化頁面標題、內容、內鏈、速度與結構化資料。",
            "每月追蹤排名、流量、詢問量與可再擴張的在地主題。",
        ],
        "proof_points": [
            {"label": "在地頁面架構", "value": "12+"},
            {"label": "可佈局長尾主題", "value": "40+"},
            {"label": "Google 商家優化項目", "value": "18"},
            {"label": "每月追蹤指標", "value": "6"},
        ],
        "districts": ["中壢市區", "內壢", "青埔", "平鎮", "楊梅", "A19 周邊"],
        "faq_items": faq_items,
        "local_business_schema": local_business_schema,
        "faq_schema": faq_schema,
    }


@app.get("/")
def index():
    bootstrap()
    return render_template("landing.html", **seo_context())


@app.post("/employees")
def add_employee():
    groups = request.form.getlist("groups")
    days = request.form.getlist("available_days")
    slots = request.form.getlist("available_slots")
    execute(
        """
        INSERT INTO employees
        (name, groups_text, available_days, available_slots, weekly_max_shifts, priority, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (
            request.form.get("name", "").strip(),
            to_csv(groups),
            to_csv(days),
            to_csv(slots),
            int(request.form.get("weekly_max_shifts", "5")),
            int(request.form.get("priority", "1")),
            request.form.get("notes", "").strip(),
        ),
    )
    return render_template("dashboard.html", **dashboard_context("已新增人員。", "employees"))


@app.post("/events")
def add_event():
    execute(
        """
        INSERT INTO events
        (date, slot, store, brand, category, required_staff, preferred_group, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            request.form.get("date", "").strip(),
            request.form.get("slot", "AM").strip(),
            request.form.get("store", "").strip(),
            request.form.get("brand", "").strip(),
            request.form.get("category", "").strip().lower(),
            int(request.form.get("required_staff", "1")),
            request.form.get("preferred_group", "").strip().lower() or request.form.get("category", "").strip().lower(),
            request.form.get("notes", "").strip(),
        ),
    )
    return render_template("dashboard.html", **dashboard_context("已新增場次。", "events"))


@app.post("/leaves")
def add_leave():
    employee_id = int(request.form.get("employee_id", "0"))
    execute(
        """
        INSERT INTO leaves (employee_id, date, slot, reason)
        VALUES (?, ?, ?, ?)
        """,
        (
            employee_id,
            request.form.get("date", "").strip(),
            request.form.get("slot", "FULL").strip(),
            request.form.get("reason", "").strip(),
        ),
    )
    return render_template("dashboard.html", **dashboard_context("已新增請假設定。", "leaves"))


@app.post("/seed/reset")
def reset_seed():
    seed_defaults(force=True)
    return render_template("dashboard.html", **dashboard_context("已重設成預設示範資料。", "employees"))


@app.post("/schedule/run")
def run_schedule():
    employees, leaves, events = build_scheduler_inputs()
    assignments, unfilled = schedule(employees, leaves, events)
    summary = build_summary(employees)
    return render_template(
        "planner.html",
        assignments=assignments,
        unfilled=unfilled,
        summary=summary,
        stats={
            "assignments": len(assignments),
            "unfilled": len(unfilled),
            "employees": len(summary),
            "events": len(events),
        },
    )


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/reload")
def reload_home():
    return redirect(url_for("index"))


if __name__ == "__main__":
    bootstrap()
    port = int(os.environ.get("PORT", "5000"))
    app.run(debug=False, host="0.0.0.0", port=port)
